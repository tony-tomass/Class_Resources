package com.mobile.sharedpreferencesexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "MyPrefsFile";
    SharedPreferences prefs;
    int currentOrientation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, 0);

        String futureMessage = prefs.getString("futureMessage",
                "");

        if(!futureMessage.equals("")){
            TextView messageView = findViewById(R.id.message);
            messageView.setText(futureMessage);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = prefs.edit();
        EditText messageBox = findViewById(R.id.MessageInput);
        editor.putString("futureMessage", messageBox.getText().toString());
        Toast.makeText(this, messageBox.getText().toString(),Toast.LENGTH_SHORT).show();
        editor.commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "onDestroy()", Toast.LENGTH_SHORT).show();
    }
}